﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EventPlanner.Models
{
    public class GroupVoteViewModel
    {
        public List<EntertainmentPreference> EntertainmentPreferences { get; set; }
    }
}
