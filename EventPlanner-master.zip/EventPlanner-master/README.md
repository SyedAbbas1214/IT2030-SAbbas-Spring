# EventPlanner
An optimized event planner using asp.net MVC 5.
